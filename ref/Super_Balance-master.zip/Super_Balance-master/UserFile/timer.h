#ifndef __TIMER_H
#define __TIMER_H
#include "app.h"

extern u8 TIM_Flag;

void TIM1_Init(void);
void TIM8_Init(void);
void TIM7_Init(void);
void TIM10_Init(void);
void TIM11_Init(void);
#endif
