#ifndef __DELAY_H
#define __DELAY_H 			   
#include "at32f403a_407.h"

void delay_init(void);
void delay_ms(u16 nms);
void delay_us(u32 nus);

#endif





























